/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package blackjack;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Alunos
 */
public class Mesa {
    static Jogador p1, p2, p3, p4;
    public static void main(String[] args) throws InterruptedException {
        p1 = new Jogador("Lucas");
        p2 = new Jogador("Pedro");
        p3 = new Jogador("João");
        p4 = new Jogador("Tiago");
        
        p1.jogar();
        
        new Thread (() -> {
            try {
                p1.jogar();
            } catch (InterruptedException ex) {
                Logger.getLogger(Mesa.class.getName()).log(Level.SEVERE, null, ex);
            }
        }).start();
        
        new Thread (() -> {
            try {
                p4.jogar();
            } catch (InterruptedException ex) {
                Logger.getLogger(Mesa.class.getName()).log(Level.SEVERE, null, ex);
            }
        }).start();

       
    }
    
}
