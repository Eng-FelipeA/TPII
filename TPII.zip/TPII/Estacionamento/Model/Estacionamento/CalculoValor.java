
package Model.Estacionamento;

public interface CalculoValor {
    
    public double calcular(long periodo, Veiculo veiculo);
    
}
