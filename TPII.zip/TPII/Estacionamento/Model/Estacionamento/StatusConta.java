
package Model.Estacionamento;

import java.io.Serializable;

public enum StatusConta implements Serializable {
    ABERTO, FECHADO;    
}
