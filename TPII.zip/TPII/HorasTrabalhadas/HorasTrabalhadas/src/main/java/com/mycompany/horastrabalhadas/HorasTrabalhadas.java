package com.mycompany.horastrabalhadas;

public class HorasTrabalhadas {
    //Atributos
    
    //Contrutor
    
    //Métodos
    public float calculaHorasTrabalhadas(float inicio, float fim) {
        float jornada = 0;
        
        //CORRIGE O CENÁRIO DE JORNADA NEGATIVA, SOMANDO 24 AO FIM 
        if(inicio > fim){
            fim = fim + 24.0f;
        }
        
        for (float i=inicio; i<fim; i++) {
            //HORAS DOBRADAS (HD)
            if(i<6.0f || i>=22.0f || (i<30.0f && i>=24.0f)){
                jornada = jornada + 2.0f;
            }
            //HORAS NORMAIS (HN)
            else if ((i>=8.0f && i<18.0f) || (i>=32.0f && i<42.0f)) {
                jornada = jornada + 1.0f;
            }
            //HORAS SEMI-DOBRADAS (HSD)
            else if ((i>=6.0f && i<8.0f) || (i>=18.0f && i<=22.0f)
                    || (i>=30.0f && i<32.0f) || (i>=42.0f && i<=46.0f)) {
                jornada = jornada + 1.5f;
            }
        
        }
        //SE A JORNADA ULTRAPASSAR 6H ADICIONA-SE 1.5H NA JORNADA
        if (fim - inicio > 6.0f) {
            jornada = jornada + 1.5f;
        }
        
        return jornada;
    }
}
