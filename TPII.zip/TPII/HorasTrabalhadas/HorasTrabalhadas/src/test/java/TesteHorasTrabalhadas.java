import com.mycompany.horastrabalhadas.HorasTrabalhadas;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class TesteHorasTrabalhadas {
    @Test
    public void calculaHorasTrabalhadas(){
        HorasTrabalhadas jornada = new HorasTrabalhadas();
        
        float resultado1 = jornada.calculaHorasTrabalhadas(8.0f, 12.0f);
        assertEquals(4.0f, resultado1);
        
        float resultado2 = jornada.calculaHorasTrabalhadas(13.0f, 18.0f);
        assertEquals(5.0f, resultado2);
        
        float resultado3 = jornada.calculaHorasTrabalhadas(8.0f, 18.0f);
        assertEquals(11.5f, resultado3);
        
        float resultado4 = jornada.calculaHorasTrabalhadas(14.0f, 19.0f);
        assertEquals(5.5f, resultado4);
        
        float resultado5 = jornada.calculaHorasTrabalhadas(6.0f, 12.0f);
        assertEquals(7.0f, resultado5);
        
        float resultado6 = jornada.calculaHorasTrabalhadas(6.0f, 13.0f);
        assertEquals(9.5f, resultado6);
        
        float resultado7 = jornada.calculaHorasTrabalhadas(17.0f, 23.0f);
        assertEquals(9.0f, resultado7);
        
        float resultado8 = jornada.calculaHorasTrabalhadas(0.0f, 9.0f);
        assertEquals(17.5f, resultado8);
        
        float resultado9 = jornada.calculaHorasTrabalhadas(22.0f, 2.0f);
        assertEquals(8.0f, resultado9);
        
        float resultado10 = jornada.calculaHorasTrabalhadas(14.0f, 2.0f);
        assertEquals(19.5f, resultado10);
    }
}
